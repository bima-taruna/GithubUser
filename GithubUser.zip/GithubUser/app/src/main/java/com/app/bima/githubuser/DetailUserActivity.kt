package com.app.bima.githubuser

import android.annotation.SuppressLint
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewTreeObserver
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.fragment.app.commit
import com.app.bima.githubuser.databinding.ActivityDetailUserBinding
import com.app.bima.githubuser.fragment.ContainerFragment
import com.app.bima.githubuser.viewmodel.DetailViewModel
import com.bumptech.glide.Glide

class DetailUserActivity : AppCompatActivity() {
    private val detailViewModel by viewModels<DetailViewModel>()
    private lateinit var detailUserBinding: ActivityDetailUserBinding
    companion object {
        const val USERNAME = "username"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        detailUserBinding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(detailUserBinding.root)

        window.statusBarColor = ContextCompat.getColor(this,R.color.black_900)
        detailUserBinding.svDetail.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            @SuppressLint("ClickableViewAccessibility")
            override fun onGlobalLayout() {
                val orientation = resources.configuration.orientation
                if (orientation == Configuration.ORIENTATION_PORTRAIT) {
                    detailUserBinding.svDetail.setOnTouchListener { _, _ -> true }
                } else {
                    detailUserBinding.svDetail.setOnTouchListener { _, _ -> false }
                }
                detailUserBinding.svDetail.viewTreeObserver.removeOnGlobalLayoutListener(this)
            }
        })


        val username = intent.getStringExtra(USERNAME)
        val bundle = Bundle()
        bundle.putString("username_dari_activity", username)

        detailViewModel.detailGithubUser.observe(this) { detail ->
            setDetailUser(detail)
        }

        if (detailViewModel.detailGithubUser.value == null) {
            detailViewModel.getUserDetail(username)
        }

        detailViewModel.isDetailLoading.observe(this) {
            showLoading(it)
        }

        detailViewModel.toastDetailMessageObserver.observe(this) { message ->
            Toast.makeText(
                this,
                message,
                Toast.LENGTH_SHORT
            ).show()
        }

        val fragmentManager = supportFragmentManager
        val fragmentContainer = ContainerFragment()
        fragmentContainer.arguments = bundle
        val fragment = fragmentManager.findFragmentByTag(ContainerFragment::class.java.simpleName)
        if (fragment !is ContainerFragment) {
            fragmentManager.commit {
                add(R.id.fr_detail, fragmentContainer, ContainerFragment::class.java.simpleName)
            }
        }
    }

    private fun setDetailUser(detail:UserDetailResponse) {
        Glide.with(this)
            .load(detail.avatarUrl)
            .circleCrop()
            .into(detailUserBinding.ivProfilePicture)
        detailUserBinding.tvUsername.text = detail.login
        detailUserBinding.tvName.text = detail.name.toString()
        detailUserBinding.tvFollowers.text = detail.followers.toString()
        detailUserBinding.tvFollowing.text = detail.following.toString()

    }

    private fun showLoading(isLoading: Boolean) {
        detailUserBinding.detailProgressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}