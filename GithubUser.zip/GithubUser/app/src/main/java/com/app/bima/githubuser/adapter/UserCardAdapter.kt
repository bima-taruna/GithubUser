package com.app.bima.githubuser.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.app.bima.githubuser.DetailUserActivity
import com.app.bima.githubuser.ItemsItem
import com.app.bima.githubuser.databinding.ItemUserCardBinding
import com.bumptech.glide.Glide

class UserCardAdapter(private val listUser: ArrayList<ItemsItem>): RecyclerView.Adapter<UserCardAdapter.ViewHolder>() {


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemUserCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.tvUserName.text = listUser[position].login
        Glide.with(holder.itemView.context)
            .load(listUser[position].avatar_url)
            .into(holder.binding.ivUserPhoto)
        holder.itemView.setOnClickListener {
        val detailIntent = Intent(holder.itemView.context, DetailUserActivity::class.java)
        detailIntent.putExtra(DetailUserActivity.USERNAME, listUser[position].login)
            holder.itemView.context.startActivity(detailIntent)
        }
    }

    override fun getItemCount(): Int {
       return listUser.size
    }

    class ViewHolder(var binding:ItemUserCardBinding):RecyclerView.ViewHolder(binding.root)

}