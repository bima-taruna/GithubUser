package com.app.bima.githubuser.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.app.bima.githubuser.ApiConfig
import com.app.bima.githubuser.UserDetailResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel: ViewModel() {

    private val _detailGithubUser = MutableLiveData<UserDetailResponse>()
    val detailGithubUser:LiveData<UserDetailResponse> = _detailGithubUser

    private val _isDetailLoading = MutableLiveData<Boolean>()
    val isDetailLoading: LiveData<Boolean> = _isDetailLoading

    private val _toastDetailMessageObserver = MutableLiveData<String?>()
    val toastDetailMessageObserver:LiveData<String?> = _toastDetailMessageObserver



    fun getUserDetail(username: String?) {
        _isDetailLoading.value = true
        val client = ApiConfig.getApiService().getDetailUser(username)
        client.enqueue(object : Callback<UserDetailResponse> {
            override fun onResponse(
                call: Call<UserDetailResponse>,
                response: Response<UserDetailResponse>
            ) {
                _isDetailLoading.value = false
                if (response.isSuccessful) {
                    _detailGithubUser.value = response.body()
                } else {
                    Log.e("DetailViewModel", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<UserDetailResponse>, t: Throwable) {
                _isDetailLoading.value = false
                Log.e("DetailViewModel", "onFailure: ${t.message.toString()}")
                _toastDetailMessageObserver.value = "Error : ${t.message}"
            }
        })
    }


}