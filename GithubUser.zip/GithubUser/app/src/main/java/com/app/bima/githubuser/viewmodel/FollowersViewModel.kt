package com.app.bima.githubuser.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.app.bima.githubuser.ApiConfig
import com.app.bima.githubuser.ItemsItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowersViewModel: ViewModel() {
    private val _followersUser = MutableLiveData<List<ItemsItem>>()
    val followersUser: LiveData<List<ItemsItem>> = _followersUser

    private val _isLoading = MutableLiveData<Boolean>()
    val followersIsLoading: LiveData<Boolean> = _isLoading

    private val _toastMessageObserver = MutableLiveData<String?>()
    val toastMessageObserver:LiveData<String?> = _toastMessageObserver


    fun getFollowers(username: String?) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getFollowers(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _followersUser.value = response.body()

                    }
                } else {
                    Log.e("FollowerViewModel", "onFailure: ${response.message()}")

                }
            }
            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoading.value = false
                Log.e("FollowerViewModel", "onFailure: ${t.message}")
                _toastMessageObserver.value = "Error : ${t.message}"
            }
        })
    }


}