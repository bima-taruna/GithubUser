package com.app.bima.githubuser.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.app.bima.githubuser.ApiConfig
import com.app.bima.githubuser.ItemsItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingViewModel: ViewModel() {
    private val _followingUser = MutableLiveData<List<ItemsItem>>()
    val followingUser: LiveData<List<ItemsItem>> = _followingUser

    private val _isLoading = MutableLiveData<Boolean>()
    val followingIsLoading: LiveData<Boolean> = _isLoading

    private val _toastMessageObserver = MutableLiveData<String?>()
    val toastMessageObserver:LiveData<String?> = _toastMessageObserver

    fun getFollowing(username: String?) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getFollowing(username)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _followingUser.value = response.body()

                    }
                } else {
                    Log.e("FollowingViewModel", "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoading.value = false
                Log.e("FollowingViewModel", "onFailure: ${t.message}")
                _toastMessageObserver.value = "Error : ${t.message}"
            }
        })
    }
}