package com.app.bima.githubuser.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.app.bima.githubuser.ApiConfig
import com.app.bima.githubuser.GithubUserResponse
import com.app.bima.githubuser.ItemsItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel: ViewModel() {

    private val _githubUser = MutableLiveData<List<ItemsItem>>()
    val githubUser:LiveData<List<ItemsItem>> = _githubUser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

    private val _toastMainMessageObserver = MutableLiveData<String?>()
    val toastMainMessageObserver:LiveData<String?> = _toastMainMessageObserver

    companion object{
        private const val TAG = "MainViewModel"
        private const val USERNAME = "a"
    }

    init {
        getGithubUser()
    }

     fun getGithubUser(query:String = USERNAME) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getGithubUser(query)
        client.enqueue(object : Callback<GithubUserResponse> {
            override fun onResponse(
                call: Call<GithubUserResponse>,
                response: Response<GithubUserResponse>
            ) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        _githubUser.value = response.body()?.items

                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GithubUserResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
                _toastMainMessageObserver.value = "Error : ${t.message}"
            }
        })

    }}